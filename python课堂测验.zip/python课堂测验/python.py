﻿import math
print("He said\"I\'m fine .\"")
print('''昔人已乘黄鹤去
此地空余黄鹤楼
黄鹤一去不复返
白云千载空悠悠
晴川历历汉阳树，
芳草萋萋鹦鹉洲
日暮乡关何处是？
烟波江上使人愁。''')
s=input("输入"+"一个"+"偶数:")
a=int(s)
total=0.0
for i in range(1,a,2):
    total+=math.tan(i)
print(total)
c=4
if c==3:
     print("c=3")
elif c==5:
     print("c=5")
elif c==2:
     print("c=2")
else:
    print("c=4")
print("s的长度："+str(len(s)))
print(type(s))
print(type(a))
print(type(total))

