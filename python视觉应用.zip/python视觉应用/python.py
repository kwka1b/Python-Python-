import cv2
import numpy as np
#print(cv2.getVersionString())
#image=cv2.imread("11.jpg")
#print(image.shape)
#cv2.imshow("image",image)
#
#cv2.imshow("red",image[:,:,2])
#cv2.imshow("green",image[:,:,1])
#cv2.imshow("blue",image[:,:,0])
#
#gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
#cv2.imshow("gray",gray)

#crop=image[100:400,100:600]
#cv2.imshow("crop",crop)

image1=np.zeros([300,300,3],dtype=np.uint8)
#cv2.line(image1,(100,200),(250,250),(255,0,0),2)
#cv2.rectangle(image1,(30,100),(60,150),(0,255,0),2)
cv2.putText(image1,"hello World!",(100,50),0,1,(255,255,255),2,1)
cv2.imshow("image",image1)
cv2.waitKey()